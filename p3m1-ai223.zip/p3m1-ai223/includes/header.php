
<link rel="stylesheet"
      type="text/css"
      href="styles/all.css"
      media="all">

<!-- Set encoding -->
<meta charset="utf-8">

<!-- Set icon -->
<!-- Source: http://www.clker.com/cliparts/a/a/b/a/1194986147544723915applf.svg.hi.png -->
<link rel="icon"
      type="images/jpg"
      href="images/icon.jpg">
<!-- Set title -->
<title>Ithaca's 2017 Apple Harvest Festival</title>

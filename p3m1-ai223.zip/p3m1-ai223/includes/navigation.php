<header>
  <nav>
    <ul>
      <li><a href="index.php">Home</a></li><!--
   --><li><a href="events.php">Events</a><!--
   --><li><a href="music.php">Music</a><!--
   --><li><a href="food.php">Food</a><!--
   --><li><a href="applications.php">Applications</a><!--
   --><li><a href="about.php">About</a><!--
   --><li><a href="contact.php">Contact</a><!--
   --></ul>
  </nav>
</header>
